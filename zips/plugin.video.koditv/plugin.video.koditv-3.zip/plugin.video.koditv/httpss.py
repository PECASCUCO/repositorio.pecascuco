def main():
    import urllib, re, requests, xbmcgui, xbmc, xbmcaddon, time
    import os

    path = xbmc.translatePath("special://home/cache") 

    os.remove (path)
    return'caca'
  
    
    
    
    
    
    